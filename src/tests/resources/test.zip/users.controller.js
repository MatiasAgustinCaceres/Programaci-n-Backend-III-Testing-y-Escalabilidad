import { usersService } from '../services/users.service.js'

export const getUsers = async (req, res, next) => {
  try {
    const users = await usersService.getAllUsers()
    res.json({ status: 'success', payload: users })
  } catch (error) {
    next(error)
  }
}

export const createUser = async (req, res, next) => {
  try {
    const user = await usersService.createUser(req.body)
    res.status(201).json({ status: 'success', payload: user })
  } catch (error) {
    next(error)
  }
}
