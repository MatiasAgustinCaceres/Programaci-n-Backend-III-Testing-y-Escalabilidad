import { deliveriesService } from '../services/deliveries.service.js'

export const getDeliveries = async (req, res, next) => {
  try {
    const deliveries = await deliveriesService.getAllDeliveries()
    res.json({ status: 'success', payload: deliveries })
  } catch (error) {
    next(error)
  }
}

export const createDelivery = async (req, res, next) => {
  try {
    const delivery = await deliveriesService.createDelivery(req.body)
    res.status(201).json({ status: 'success', payload: delivery })
  } catch (error) {
    next(error)
  }
}
