import { productsService } from '../services/products.service.js'

export const getProducts = async (req, res, next) => {
  try {
    const products = await productsService.getAvailableProducts()
    res.json({ status: 'success', payload: products })
  } catch (error) {
    next(error)
  }
}

export const createProduct = async (req, res, next) => {
  try {
    const product = await productsService.createProduct(req.body)
    res.status(201).json({ status: 'success', payload: product })
  } catch (error) {
    next(error)
  }
}